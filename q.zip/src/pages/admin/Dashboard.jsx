import { Users, PieChart, Rocket, Settings } from "lucide-react";
import PageHeader from "../../components/PageHeader";
import StatsCard from "../../components/StatsCard";

const AdminDashboard = () => {
  return (
    <>
      <PageHeader
        title="Academy Control Center"
        description="Track user growth, engagement metrics, and placement outcomes across all programs."
        actions={
          <button className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-semibold text-brand-600 shadow-sm transition hover:bg-white/90">
            <Settings className="h-4 w-4" />
            Configure Reports
          </button>
        }
      />
      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
        <StatsCard icon={Users} value="4,820" label="Total Learners" trend="+320 this month" />
        <StatsCard icon={Users} value="312" label="Tutors & Mentors" trend="+12 onboarded" />
        <StatsCard icon={PieChart} value="78%" label="Avg Engagement" trend="+5% vs last month" />
        <StatsCard icon={Rocket} value="186" label="Offers Secured" trend="+28 QoQ" />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
          <h3 className="text-lg font-semibold text-slate-900">Engagement Overview</h3>
          <p className="mt-1 text-sm text-slate-500">
            Monitor cohort health, class attendance, and peer learning contributions.
          </p>
          <div className="mt-6 h-72 rounded-2xl border border-dashed border-slate-200 bg-slate-50 text-center text-sm text-slate-400">
            <div className="flex h-full flex-col items-center justify-center">
              <PieChart className="h-10 w-10 text-slate-300" />
              <p className="mt-3 font-semibold text-slate-500">Chart Placeholder</p>
              <p>Daily active learners vs engagement segments</p>
            </div>
          </div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
          <h3 className="text-lg font-semibold text-slate-900">Placement Outcomes</h3>
          <div className="mt-4 space-y-3 text-sm text-slate-600">
            {[
              "Top recruiters: Razorpay, Atlassian, Meesho, Gojek",
              "Average CTC hike: 148%",
              "Most in-demand roles: Backend Engineer, Platform Engineer, SDE II",
            ].map((item) => (
              <div key={item} className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
                {item}
              </div>
            ))}
          </div>
          <button className="mt-5 rounded-xl bg-brand-700 px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-600">
            View Placement Report
          </button>
        </div>
      </div>
    </>
  );
};

export default AdminDashboard;

