import { ArrowRight, BookOpenCheck } from "lucide-react";

const ContinueLearningCard = () => {
  const progress = 64;

  return (
    <section className="bg-white/80 backdrop-blur-md rounded-2xl border border-brintelli-border shadow-card p-6 hover:shadow-soft transition" id="continue">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-wide text-textMuted">Continue Learning</p>
          <h2 className="mt-1 text-xl font-semibold tracking-tight text-text">Backend Engineering Mastery</h2>
          <p className="text-sm text-textSoft">Mentor: Aman Sharma · Last lesson completed yesterday</p>
        </div>
        <BookOpenCheck className="h-10 w-10 text-brand-500" />
      </div>

      <div className="mt-5 space-y-2">
        <div className="flex items-center justify-between text-sm text-textSoft">
          <span>Course Progress</span>
          <span className="font-semibold text-text">{progress}%</span>
        </div>
        <div className="h-2.5 w-full overflow-hidden rounded-full bg-brintelli-baseAlt">
          <div
            className="h-full rounded-full bg-brand-500 transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      <div className="mt-4 rounded-xl border border-brintelli-border bg-brintelli-baseAlt px-3 py-2 text-xs text-textSoft">
        Next class: API Gateways & Rate Limiting · Nov 24 · 9:00 PM
      </div>

      <button className="mt-5 inline-flex w-full items-center justify-center gap-2 bg-gradient-brintelli-alt text-white font-semibold shadow-glow rounded-xl py-3 transition hover:opacity-90">
        Continue Learning
        <ArrowRight className="h-4 w-4" />
      </button>
    </section>
  );
};

export default ContinueLearningCard;

