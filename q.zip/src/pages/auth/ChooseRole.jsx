import { useNavigate } from "react-router-dom";
import {
  GraduationCap,
  UsersRound,
  HeartHandshake,
  ShieldCheck,
  BriefcaseBusiness,
} from "lucide-react";

const cards = [
  {
    role: "student",
    title: "Student",
    description: "Track learning, live classes, and assignments.",
    icon: GraduationCap,
    href: "/student/dashboard",
  },
  {
    role: "tutor",
    title: "Tutor",
    description: "Manage courses, content, and learner progress.",
    icon: UsersRound,
    href: "/tutor/dashboard",
  },
  {
    role: "lsm",
    title: "Learning Success Manager",
    description: "Support mentees and keep outcomes on track.",
    icon: HeartHandshake,
    href: "/lsm/dashboard",
  },
  {
    role: "admin",
    title: "Admin",
    description: "Configure programs, teams, and analytics.",
    icon: ShieldCheck,
    href: "/admin/dashboard",
  },
  {
    role: "placement",
    title: "Placement Assistance",
    description: "Coordinate interviews, offers, and company connects.",
    icon: BriefcaseBusiness,
    href: "/placement/dashboard",
  },
];

const ChooseRole = () => {
  const navigate = useNavigate();

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-100 px-4 py-10">
      <div className="w-full max-w-5xl rounded-2xl border border-slate-200 bg-white shadow-soft">
        <div className="bg-gradient-to-br from-brand-500 via-brand-500/90 to-accent-500 px-6 py-6 text-white">
          <p className="text-xs font-semibold uppercase tracking-wide text-white/80">
            Brintelli Tech Academy
          </p>
          <h1 className="text-2xl font-semibold">Select your workspace</h1>
          <p className="mt-2 text-sm text-white/80">
            Choose the portal area you need to access right now. You can switch roles anytime.
          </p>
        </div>
        <div className="grid gap-4 px-6 py-6 md:grid-cols-2 lg:grid-cols-3">
          {cards.map((card) => {
            const Icon = card.icon;
            return (
              <button
                key={card.role}
                onClick={() => navigate(card.href)}
                className="flex h-full flex-col gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-5 text-left text-slate-600 transition hover:-translate-y-1 hover:border-brand-300 hover:bg-white hover:text-slate-700 hover:shadow-soft"
              >
                <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-brand-500/10 to-accent-500/10 text-brand-600">
                  <Icon className="h-6 w-6" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-slate-900">{card.title}</h2>
                  <p className="mt-1 text-sm text-slate-500">{card.description}</p>
                </div>
                <span className="mt-auto text-sm font-semibold text-brand-600">
                  Enter {card.title} Portal →
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ChooseRole;


