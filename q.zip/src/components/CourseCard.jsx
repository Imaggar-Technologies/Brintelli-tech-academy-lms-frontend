import { ArrowRight, Clock3 } from "lucide-react";
import ProgressBar from "./ProgressBar";

const CourseCard = ({ title, mentor, progress = 0, nextLesson, category = "Specialization" }) => {
  return (
    <div className="group flex flex-col overflow-hidden rounded-2xl border border-brintelli-border bg-white shadow-soft transition hover:-translate-y-1 hover:shadow-soft/80">
      <div className="relative h-36 w-full bg-gradient-to-br from-brand-400 via-brand-500 to-brand-600">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(255,255,255,0.25),_transparent_60%)]" />
        <div className="absolute bottom-4 left-4 flex flex-col gap-1 text-white">
          <span className="text-xs font-semibold uppercase tracking-wide text-white/70">
            {category}
          </span>
          <h3 className="text-lg font-semibold leading-tight">{title}</h3>
          {mentor && <p className="text-xs text-white/80">Mentor: {mentor}</p>}
        </div>
      </div>
      <div className="flex flex-1 flex-col gap-4 p-5">
        <div className="flex items-center justify-between text-sm text-text-soft">
          <span>Course Progress</span>
          <span className="font-semibold text-text-base">{progress}%</span>
        </div>
        <ProgressBar value={progress} />
        {nextLesson && (
          <div className="flex items-center gap-2 rounded-xl border border-brintelli-border bg-brintelli-base px-3 py-2 text-xs text-text-soft">
            <Clock3 className="h-4 w-4 text-brand-500" />
            Next class: {nextLesson}
          </div>
        )}
        <button className="mt-auto inline-flex items-center justify-between rounded-xl bg-gradient-to-r from-brand-500 to-brand-600 px-4 py-2 text-sm font-semibold text-white transition hover:opacity-90">
          Continue Learning
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

export default CourseCard;

