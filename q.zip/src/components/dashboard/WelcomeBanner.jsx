const WelcomeBanner = () => {
  return (
    <section className="relative overflow-hidden rounded-2xl bg-gradient-brintelli text-white shadow-soft">
      <div className="pointer-events-none absolute -right-24 top-0 h-64 w-64 rounded-full bg-white/25 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 left-10 h-64 w-64 rounded-full bg-white/20 blur-3xl" />
      <div className="relative flex flex-col gap-6 p-6 sm:flex-row sm:items-center sm:justify-between">
        <div className="space-y-3">
          <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-sm font-medium">
            <span className="text-xl">👋</span>
            Welcome back, Aishwarya
          </span>
          <h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">
            Your Learning Tracks are on schedule
          </h1>
          <p className="max-w-lg text-sm text-white/80">
            Access all enrolled programs, monitor progress, and jump back into live sessions or assignments without
            losing momentum.
          </p>
        </div>
        <button className="inline-flex items-center gap-2 bg-gradient-brintelli-alt text-white font-semibold shadow-glow rounded-xl px-5 py-3 transition hover:opacity-90">
          View Learning Plan →
        </button>
      </div>
    </section>
  );
};

export default WelcomeBanner;

