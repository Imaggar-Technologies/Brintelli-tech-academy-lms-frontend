const palette = {
  // Base Surfaces
  base: "#EEF2FF",
  baseAlt: "#E1E6FF",
  card: "#FFFFFF",

  // Borders / Separators
  border: "#CBD5FE",

  // Brand Core
  primary: "#4338CA",
  primarySoft: "#6E72FF",
  primaryDark: "#31249A",

  // Complement / Accent Color
  accent: "#1BAFCF",
  accentSoft: "#9C4DFF",

  // Neutral Whites
  white: "#FFFFFF",

  // Glass Blur Layers
  glass06: "rgba(255,255,255,0.65)",
  glass10: "rgba(255,255,255,0.92)",

  // Text System
  text: "#0B1533",
  textSoft: "#475569",
  textMuted: "#7A8498",
};


/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          400: palette.primarySoft,
          500: palette.primary,
          600: palette.primaryDark,
          DEFAULT: palette.primary,
        },
        accent: {
          400: palette.accentSoft,
          500: palette.accent,
          600: palette.primary,
        },
        brintelli: {
          base: palette.base,
          baseAlt: palette.baseAlt,
          card: palette.card,
          border: palette.border,
          primary: palette.primary,
          primarySoft: palette.primarySoft,
          primaryDark: palette.primaryDark,
          accent: palette.accent,
          glass06: palette.glass06,
          glass10: palette.glass10,
          text: palette.text,
          textSoft: palette.textSoft,
          textMuted: palette.textMuted,
        },
        surface: {
          DEFAULT: palette.card,
          strong: palette.glass10,
          panel: palette.baseAlt,
          card: palette.card,
        },
        text: {
          base: palette.text,
          soft: palette.textSoft,
          muted: palette.textMuted,
        },
        white: palette.white,
        border: palette.border,
      },
      boxShadow: {
        soft: "0 20px 45px -24px rgba(79, 70, 229, 0.25)",
        glow: "0 0 35px rgba(79, 70, 229, 0.25)",
        card: "0 18px 35px -20px rgba(15, 23, 42, 0.15)",
      },
      borderRadius: {
        xl: "1rem",
        "2xl": "1.25rem",
      },
      backgroundImage: {
        "gradient-brintelli": `linear-gradient(135deg, ${palette.primarySoft}, ${palette.primary})`,
        "gradient-brintelli-alt": `linear-gradient(120deg, ${palette.primary}, ${palette.accent})`,
        "gradient-light": `linear-gradient(160deg, ${palette.base}, ${palette.white})`,
        "grid-brintelli": `linear-gradient(to right, rgba(79,70,229,0.08) 1px, transparent 1px),
          linear-gradient(to bottom, rgba(121,80,242,0.08) 1px, transparent 1px)`,
      },
      backdropBlur: {
        xs: "3px",
      },
    },
  },
  plugins: [],
};

