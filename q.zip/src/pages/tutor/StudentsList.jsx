import { UsersRound } from "lucide-react";
import PageHeader from "../../components/PageHeader";
import Table from "../../components/Table";

const columns = [
  { key: "name", title: "Student" },
  { key: "cohort", title: "Cohort" },
  { key: "attendance", title: "Attendance" },
  { key: "progress", title: "Progress" },
  { key: "status", title: "Status" },
];

const data = [
  { id: 1, name: "Aishwarya Kumar", cohort: "BE-2025A", attendance: "92%", progress: "76%", status: "On Track" },
  { id: 2, name: "Karan Gupta", cohort: "BE-2025A", attendance: "85%", progress: "61%", status: "Needs Support" },
  { id: 3, name: "Shraddha Patil", cohort: "BE-2025A", attendance: "97%", progress: "82%", status: "Star Performer" },
  { id: 4, name: "Harsh Yadav", cohort: "BE-2025A", attendance: "71%", progress: "58%", status: "At Risk" },
];

const TutorStudentsList = () => {
  return (
    <>
      <PageHeader
        title="Student Directory"
        description="Track attendance, progress, and personalize outreach for your cohort."
        actions={
          <button className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-semibold text-brand-600 shadow-sm transition hover:bg-white/90">
            <UsersRound className="h-4 w-4" />
            Create Cohort Group
          </button>
        }
      />
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-lg font-semibold text-slate-900">Cohort BE-2025A</h3>
            <p className="text-sm text-slate-500">Monitor trends and plan interventions proactively.</p>
          </div>
          <div className="flex gap-3">
            <button className="rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:border-brand-300 hover:text-brand-600">
              Download CSV
            </button>
          <button className="rounded-xl bg-brand-700 px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-600">
              Share Insights
            </button>
          </div>
        </div>
        <div className="mt-4">
          <Table columns={columns} data={data} />
        </div>
      </div>
    </>
  );
};

export default TutorStudentsList;

