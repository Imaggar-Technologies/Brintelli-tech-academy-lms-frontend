import { BriefcaseBusiness, Target } from "lucide-react";
import PageHeader from "../../components/PageHeader";
import Table from "../../components/Table";

const columns = [
  { key: "company", title: "Company" },
  { key: "roles", title: "Roles" },
  { key: "offers", title: "Offers" },
  { key: "avgCtc", title: "Avg CTC" },
  { key: "status", title: "Status" },
];

const data = [
  { id: 1, company: "Razorpay", roles: "Backend Engineer", offers: 12, avgCtc: "26 LPA", status: "Closed" },
  { id: 2, company: "Atlassian", roles: "Platform Engineer", offers: 9, avgCtc: "32 LPA", status: "Interviews" },
  { id: 3, company: "Meesho", roles: "SDE II", offers: 15, avgCtc: "24 LPA", status: "Shortlisting" },
];

const AdminPlacement = () => {
  return (
    <>
      <PageHeader
        title="Placement Operations"
        description="Orchestrate company collaborations, track offers, and maximize learner outcomes."
        actions={
          <button className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-semibold text-brand-600 shadow-sm transition hover:bg-white/90">
            <BriefcaseBusiness className="h-4 w-4" />
            Add Hiring Partner
          </button>
        }
      />
      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-900">Company Pipeline</h3>
            <button className="rounded-xl bg-brand-700 px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-600">
              Export Pipeline
            </button>
          </div>
          <div className="mt-4">
            <Table columns={columns} data={data} />
          </div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
          <h3 className="text-lg font-semibold text-slate-900">Priority Actions</h3>
          <div className="mt-4 space-y-3 text-sm text-slate-600">
            {[
              "Follow up with Razorpay HR for offer letters.",
              "Confirm interview slots with Atlassian panel.",
              "Share success stories for upcoming marketing push.",
            ].map((item) => (
              <div key={item} className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
                {item}
              </div>
            ))}
          </div>
          <button className="mt-5 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-brand-500 to-accent-500 px-4 py-2 text-sm font-semibold text-white shadow-soft transition hover:brightness-95">
            <Target className="h-4 w-4" />
            Update Goal Tracker
          </button>
        </div>
      </div>
    </>
  );
};

export default AdminPlacement;

