import { Mic, MicOff, Monitor, PlayCircle, Square, Users } from "lucide-react";
import PageHeader from "../../components/PageHeader";

const TutorLiveClassController = () => {
  return (
    <>
      <PageHeader
        title="Live Class Controller"
        description="Manage your live session, interact with participants, and trigger polls seamlessly."
        actions={
          <>
            <button className="rounded-xl bg-white/10 px-4 py-2 text-sm font-semibold text-white transition hover:bg-white/20">
              Test Studio
            </button>
            <button className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-semibold text-brand-600 shadow-sm transition hover:bg-white/90">
              Enter Control Room
            </button>
          </>
        }
      />
      <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
          <div className="aspect-video w-full rounded-2xl border border-dashed border-slate-200 bg-slate-100">
            <div className="flex h-full flex-col items-center justify-center text-slate-500">
              <Monitor className="h-10 w-10 text-slate-400" />
              <p className="mt-3 text-sm font-semibold text-slate-500">Live session preview</p>
              <p className="text-xs text-slate-400">Stream will appear once the class starts</p>
            </div>
          </div>
          <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
            <div className="flex gap-3">
              <button className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-brand-500 to-accent-500 px-5 py-2 text-sm font-semibold text-white shadow-soft transition hover:brightness-95">
                <PlayCircle className="h-4 w-4" />
                Start Class
              </button>
              <button className="inline-flex items-center gap-2 rounded-xl border border-brand-700/30 bg-brand-700/20 px-5 py-2 text-sm font-semibold text-brand-700 transition hover:bg-brand-700/25">
                <Square className="h-4 w-4" />
                End Session
              </button>
            </div>
            <div className="flex gap-2">
              <button className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 transition hover:border-brand-200 hover:text-brand-600">
                <Mic className="h-5 w-5" />
              </button>
              <button className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 transition hover:border-brand-200 hover:text-brand-600">
                <MicOff className="h-5 w-5" />
              </button>
            </div>
          </div>
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <h4 className="text-sm font-semibold text-slate-900">Polls & Engagement</h4>
              <p className="mt-1 text-xs text-slate-500">Launch quick questions to check understanding.</p>
              <div className="mt-3 flex flex-col gap-2 text-xs text-slate-500">
                <button className="rounded-xl border border-slate-200 px-3 py-2 text-left transition hover:border-brand-200 hover:text-brand-600">
                  Launch prior knowledge poll
                </button>
                <button className="rounded-xl border border-slate-200 px-3 py-2 text-left transition hover:border-brand-200 hover:text-brand-600">
                  Quiz: Cache eviction strategies
                </button>
              </div>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <h4 className="text-sm font-semibold text-slate-900">Class Notes</h4>
              <textarea
                rows={5}
                placeholder="Keep cue points or share quick notes with attendees..."
                className="mt-3 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm text-slate-600 outline-none ring-brand-200 transition focus:border-brand-300 focus:ring-2"
              />
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-slate-900">Participants</h3>
              <span className="inline-flex items-center gap-2 rounded-full bg-brand-600/15 px-3 py-1 text-xs font-semibold text-brand-600">
                <Users className="h-4 w-4" />
                92 joined
              </span>
            </div>
            <div className="mt-4 space-y-3 text-sm text-slate-600">
              {["Vivek S", "Shraddha P", "Madhav T", "Ananya R"].map((name) => (
                <div key={name} className="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3">
                  <span className="font-semibold text-slate-800">{name}</span>
                  <button className="text-xs font-semibold text-brand-600">Spotlight</button>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
            <h3 className="text-lg font-semibold text-slate-900">Broadcast Messages</h3>
            <div className="mt-3 space-y-2 text-sm text-slate-600">
              <button className="w-full rounded-xl border border-slate-200 px-4 py-2 text-left transition hover:border-brand-200 hover:text-brand-600">
                Share assignment dropbox link
              </button>
              <button className="w-full rounded-xl border border-slate-200 px-4 py-2 text-left transition hover:border-brand-200 hover:text-brand-600">
                Remind about break-out activity
              </button>
              <button className="w-full rounded-xl border border-slate-200 px-4 py-2 text-left transition hover:border-brand-200 hover:text-brand-600">
                Encourage participation & questions
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default TutorLiveClassController;

