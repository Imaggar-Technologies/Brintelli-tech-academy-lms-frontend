import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

const monthNames = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

const Calendar = () => {
  const today = new Date();
  const [reference, setReference] = useState(new Date());
  const [selected, setSelected] = useState(today.getDate());

  const { monthName, year, days } = useMemo(() => {
    const month = reference.getMonth();
    const yearValue = reference.getFullYear();
    const firstDay = new Date(yearValue, month, 1).getDay();
    const totalDays = new Date(yearValue, month + 1, 0).getDate();

    const placeholderStart = (firstDay + 6) % 7; // convert Sunday start -> Monday start
    const grid = [];

    for (let i = 0; i < placeholderStart; i += 1) {
      grid.push(null);
    }
    for (let day = 1; day <= totalDays; day += 1) {
      grid.push(day);
    }

    return {
      monthName: monthNames[month],
      year: yearValue,
      days: grid,
    };
  }, [reference]);

  const moveMonth = (delta) => {
    const newDate = new Date(reference);
    newDate.setMonth(reference.getMonth() + delta);
    setReference(newDate);
    setSelected(1);
  };

  const currentMonth = reference.getMonth() === today.getMonth() && reference.getFullYear() === today.getFullYear();

  return (
    <section className="bg-white/80 backdrop-blur-md rounded-2xl border border-brintelli-border shadow-card p-6 hover:shadow-soft transition">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-semibold tracking-tight text-text">{monthName} {year}</h3>
          <p className="text-sm text-textSoft">Track live classes, assignments, and mentoring sessions.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => moveMonth(-1)}
            className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-brintelli-border text-textSoft transition hover:border-brand-500 hover:text-brand-500"
            aria-label="Previous month"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button
            onClick={() => moveMonth(1)}
            className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-brintelli-border text-textSoft transition hover:border-brand-500 hover:text-brand-500"
            aria-label="Next month"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-7 gap-2 text-center text-xs font-semibold uppercase tracking-wide text-textMuted">
        {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => (
          <span key={day}>{day}</span>
        ))}
      </div>

      <div className="mt-3 grid grid-cols-7 gap-2 text-center text-sm text-textSoft">
        {days.map((day, index) => {
          if (!day) {
            return <div key={`placeholder-${index}`} className="h-11 rounded-full" />;
          }

          const isToday = currentMonth && day === today.getDate();
          const isSelected = day === selected;

          return (
            <button
              key={day}
              onClick={() => setSelected(day)}
              className={[
                "flex h-11 w-full items-center justify-center rounded-full border border-transparent transition",
                isSelected
                  ? "bg-brand-500 text-white shadow-glow"
                  : isToday
                  ? "border border-brand-500 text-brand-500"
                  : "hover:border-brand-400 hover:text-brand-500",
              ].join(" ")}
            >
              {day}
            </button>
          );
        })}
      </div>
    </section>
  );
};

export default Calendar;

