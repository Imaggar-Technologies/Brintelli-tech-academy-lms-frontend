import { CalendarPlus, Clock3, UserCircle2 } from "lucide-react";
import PageHeader from "../../components/PageHeader";

const slots = [
  {
    id: 1,
    mentor: "Rohit Nair",
    role: "Sr. Engineering Manager, Swiggy",
    slot: "Nov 24 • 7:00 PM - 8:00 PM",
    focus: "System Design Round",
  },
  {
    id: 2,
    mentor: "Ishita Sharma",
    role: "Staff Engineer, Atlassian",
    slot: "Nov 25 • 8:00 PM - 9:00 PM",
    focus: "Problem Solving + CS Fundamentals",
  },
  {
    id: 3,
    mentor: "Sagar Patel",
    role: "Engineering Leader, Google",
    slot: "Nov 26 • 6:30 PM - 7:30 PM",
    focus: "Behavioral + Leadership",
  },
];

const StudentMockInterviews = () => {
  return (
    <>
      <PageHeader
        title="Mock Interviews Scheduler"
        description="Book feedback-driven mocks with industry mentors. Boost your confidence across rounds."
        actions={
          <button className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-semibold text-brand-600 shadow-sm transition hover:bg-white/90">
            View Interview Preparation Guide
          </button>
        }
      />
      <div className="grid gap-6 md:grid-cols-2">
        {slots.map((slot) => (
          <div
            key={slot.id}
            className="flex flex-col gap-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-soft transition hover:-translate-y-1 hover:shadow-soft"
          >
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-brand-500/10 to-accent-500/10 text-brand-600">
                <div className="flex h-full items-center justify-center">
                  <UserCircle2 className="h-6 w-6" />
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-slate-900">{slot.mentor}</h3>
                <p className="text-sm text-slate-500">{slot.role}</p>
              </div>
            </div>
            <div className="rounded-xl bg-slate-100 px-4 py-3 text-sm text-slate-600">
              <span className="font-semibold text-slate-900">Focus Area:</span> {slot.focus}
            </div>
            <div className="flex items-center gap-2 rounded-xl border border-dashed border-brand-200 bg-brand-50 px-4 py-3 text-sm font-semibold text-brand-700">
              <Clock3 className="h-4 w-4" />
              {slot.slot}
            </div>
            <button className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-brand-500 to-accent-500 px-4 py-2 text-sm font-semibold text-white shadow-soft transition hover:brightness-95">
              <CalendarPlus className="h-4 w-4" />
              Book This Slot
            </button>
          </div>
        ))}
      </div>
    </>
  );
};

export default StudentMockInterviews;

