import { Outlet, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import Sidebar from "./layout/Sidebar";
import Topbar from "./layout/Topbar";

const getRoleFromPath = (pathname) => {
  const [, firstSegment] = pathname.split("/");
  if (["student", "tutor", "lsm", "admin", "placement"].includes(firstSegment)) {
    return firstSegment;
  }
  return "student";
};

const AppLayout = () => {
  const location = useLocation();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const role = getRoleFromPath(location.pathname);

  useEffect(() => {
    setIsMobileSidebarOpen(false);
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-gradient-light text-text-base">
      <div className="flex min-h-screen">
        <Sidebar
          role={role}
          collapsed={isSidebarCollapsed}
          mobileOpen={isMobileSidebarOpen}
          onCloseMobile={() => setIsMobileSidebarOpen(false)}
        />
        <div className="flex min-h-screen flex-1 flex-col">
          <Topbar
            role={role}
            onToggleSidebar={() => setIsSidebarCollapsed((prev) => !prev)}
            onToggleMobileSidebar={() => setIsMobileSidebarOpen((prev) => !prev)}
            isSidebarCollapsed={isSidebarCollapsed}
          />
          <main className="relative flex-1 overflow-y-auto px-3 py-6 sm:px-6 lg:px-10">
            <div className="pointer-events-none absolute inset-0 bg-grid-brintelli/50" />
            <div className="relative mx-auto flex w-full max-w-[1500px] flex-col gap-5 sm:gap-6 lg:gap-7">
              <Outlet />
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default AppLayout;

