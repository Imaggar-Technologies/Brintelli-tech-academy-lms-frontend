import { Clock3, Monitor } from "lucide-react";

const NextLiveClassCard = () => {
  return (
    <section className="bg-white/80 backdrop-blur-md rounded-2xl border border-brintelli-border shadow-card p-6 hover:shadow-soft transition">
      <div className="flex items-start justify-between gap-3">
        <div>
          <span className="inline-flex items-center gap-2 border border-accent-500/20 bg-accent-500/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-accent-500 rounded-full">
            Live · Today · 7:30 PM
          </span>
          <h2 className="mt-3 text-xl font-semibold tracking-tight text-text">System Design Deep Dive</h2>
          <p className="text-sm text-textSoft">Mentor: Rahul Iyer · Cohort: Backend Engineering Mastery</p>
        </div>
        <Monitor className="h-10 w-10 text-brand-500" />
      </div>
      <div className="mt-5 flex items-center gap-3 text-sm text-textSoft">
        <Clock3 className="h-4 w-4 text-brand-500" />
        <span>Join 10 minutes early for lobby announcements</span>
      </div>
      <button className="mt-6 w-full bg-gradient-brintelli-alt text-white font-semibold shadow-glow rounded-xl py-3 transition hover:opacity-90">
        Join Waiting Room
      </button>
    </section>
  );
};

export default NextLiveClassCard;

