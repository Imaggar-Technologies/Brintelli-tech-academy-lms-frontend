const ProgressBar = ({ value = 0 }) => {
  const safeValue = Math.min(100, Math.max(0, value));
  return (
    <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-200">
      <div
        className="h-full rounded-full bg-gradient-to-r from-brand-400 via-brand-500 to-accent-500 transition-all"
        style={{ width: `${safeValue}%` }}
      />
    </div>
  );
};

export default ProgressBar;

