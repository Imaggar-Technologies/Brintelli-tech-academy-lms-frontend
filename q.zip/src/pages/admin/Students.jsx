import { Users } from "lucide-react";
import PageHeader from "../../components/PageHeader";
import Table from "../../components/Table";

const columns = [
  { key: "name", title: "Learner" },
  { key: "program", title: "Program" },
  { key: "status", title: "Status" },
  { key: "engagement", title: "Engagement" },
  { key: "placement", title: "Placement Stage" },
];

const data = [
  {
    id: 1,
    name: "Aishwarya Kumar",
    program: "Backend Engineering",
    status: "Active",
    engagement: "High",
    placement: "Ready",
  },
  {
    id: 2,
    name: "Karan Gupta",
    program: "Backend Engineering",
    status: "Active",
    engagement: "Medium",
    placement: "In Progress",
  },
  {
    id: 3,
    name: "Shraddha Patil",
    program: "Problem Solving",
    status: "Active",
    engagement: "High",
    placement: "Offer",
  },
];

const AdminStudents = () => {
  return (
    <>
      <PageHeader
        title="Learner Directory"
        description="Organisation-wide view of all learners, their programs, and placement readiness."
        actions={
          <button className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-semibold text-brand-600 shadow-sm transition hover:bg-white/90">
            <Users className="h-4 w-4" />
            Add Learner
          </button>
        }
      />
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-slate-900">Active Learners</h3>
          <button className="rounded-xl bg-brand-700 px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-600">
            Download Insights
          </button>
        </div>
        <div className="mt-4">
          <Table columns={columns} data={data} />
        </div>
      </div>
    </>
  );
};

export default AdminStudents;

