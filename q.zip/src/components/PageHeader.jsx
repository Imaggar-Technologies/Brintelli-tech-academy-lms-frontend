const PageHeader = ({ title, description, actions, children }) => {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-brintelli-border bg-gradient-brintelli text-white shadow-soft">
      <div className="pointer-events-none absolute -right-20 top-0 h-56 w-56 rounded-full bg-white/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 left-10 h-64 w-64 rounded-full bg-white/20 blur-3xl" />
      <div className="relative flex flex-col gap-4 p-5 md:flex-row md:items-center md:justify-between md:p-6">
        <div className="space-y-2">
          <p className="text-xs font-semibold uppercase tracking-[0.45em] text-white/70">
            Brintelli LMS Portal
          </p>
          <h2 className="text-2xl font-semibold md:text-3xl">{title}</h2>
          {description && <p className="max-w-2xl text-sm text-white/75">{description}</p>}
          {children}
        </div>
        {actions && <div className="flex shrink-0 items-center gap-3">{actions}</div>}
      </div>
    </div>
  );
};

export default PageHeader;

