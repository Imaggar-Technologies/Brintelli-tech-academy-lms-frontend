import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  GraduationCap,
  CalendarClock,
  Video,
  ClipboardList,
  ListChecks,
  MessageCircleQuestion,
  FileText,
  Terminal,
  BriefcaseBusiness,
  UsersRound,
  Settings,
  Sparkles,
} from "lucide-react";

const navItems = [
  { label: "Dashboard", to: "/student/dashboard", icon: LayoutDashboard },
  { label: "My Courses", to: "/student/my-courses", icon: GraduationCap },
  { label: "Live Classes", to: "/student/live-classes", icon: CalendarClock },
  { label: "Recordings", to: "/student/recordings", icon: Video },
  { label: "Assignments", to: "/student/assignments", icon: ClipboardList },
  { label: "Tests", to: "/student/tests", icon: ListChecks },
  { label: "Doubts", to: "/student/doubts", icon: MessageCircleQuestion },
  { label: "MCQ Practice", to: "/student/mcq-practice", icon: FileText },
  { label: "Code Playground", to: "/student/code-playground", icon: Terminal },
  { label: "Placement", to: "/student/placement-assistance", icon: BriefcaseBusiness },
  { label: "Community", to: "/student/community", icon: UsersRound },
  { label: "Settings", to: "/student/profile", icon: Settings },
];

const pinnedTools = [
  { label: "Continue Learning", to: "/student/dashboard#continue", icon: Sparkles },
  { label: "Join Live Class", to: "/student/live-classes", icon: CalendarClock },
  { label: "Placement Hub", to: "/student/placement-assistance", icon: BriefcaseBusiness },
];

const Sidebar = ({ collapsed, mobileOpen, onCloseMobile, role }) => {
  const sidebarWidth = collapsed ? "w-20" : "w-72";

  const renderLink = (item, pinned = false) => {
    const Icon = item.icon;
    return (
      <NavLink
        key={item.to}
        to={item.to}
        end={item.to === "/student/dashboard"}
        className={({ isActive }) =>
          [
            "group flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-medium transition",
            isActive
              ? "bg-white/20 text-brand-500"
              : "text-textSoft hover:bg-white/10 hover:text-brand-500",
            collapsed ? "justify-center px-3" : "",
          ].join(" ")
        }
        onClick={onCloseMobile}
      >
        <Icon className="h-5 w-5 text-textMuted group-hover:text-brand-500" />
        {!collapsed && <span className="text-sm text-textSoft font-medium">{item.label}</span>}
      </NavLink>
    );
  };

  return (
    <>
      <div
        onClick={onCloseMobile}
        className={[
          "fixed inset-0 z-30 bg-slate-900/30 transition-opacity lg:hidden",
          mobileOpen ? "opacity-100" : "pointer-events-none opacity-0",
        ].join(" ")}
      />
      <aside
        className={[
          "fixed inset-y-0 left-0 z-40 transform bg-brintelli-baseAlt shadow-card transition-transform lg:relative lg:translate-x-0",
          sidebarWidth,
          mobileOpen ? "translate-x-0" : "-translate-x-full",
        ].join(" ")}
      >
        <div className="flex h-full flex-col border-r border-brintelli-border/70 px-4 py-6">
          <div className={["flex items-center gap-3", collapsed ? "justify-center" : ""].join(" ")}>
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-brintelli text-white shadow-glow">
              BT
            </div>
            {!collapsed && (
              <div>
                <p className="text-text font-semibold text-lg leading-tight">Brintelli LMS</p>
                <p className="text-textMuted text-xs">Student Workspace</p>
              </div>
            )}
          </div>

          <div className="mt-6 flex-1 overflow-y-auto">
            <div className="flex flex-col gap-2">
              {!collapsed && (
                <p className="px-2 text-xs font-semibold uppercase tracking-wide text-textMuted">
                  Pinned tools
                </p>
              )}
              <div className="flex flex-col gap-1.5">
                {pinnedTools.map((tool) => renderLink(tool, true))}
              </div>
            </div>

            <div className="mt-6 flex flex-col gap-2">
              {!collapsed && (
                <p className="px-2 text-xs font-semibold uppercase tracking-wide text-textMuted">
                  Navigation
                </p>
              )}
              <div className="flex flex-col gap-1.5">
                {navItems.map((item) => renderLink(item))}
              </div>
            </div>
          </div>

          <div className="mt-6 rounded-2xl bg-white/60 p-4 shadow-card">
            {!collapsed ? (
              <>
                <h4 className="text-text font-semibold text-base">Need support?</h4>
                <p className="mt-1 text-xs text-textMuted">
                  Chat with your success manager anytime you feel blocked.
                </p>
                <button className="mt-4 w-full bg-gradient-brintelli-alt text-white font-semibold shadow-glow rounded-xl px-4 py-2 text-sm transition hover:opacity-90">
                  Open Help Center
                </button>
              </>
            ) : (
              <Sparkles className="mx-auto h-5 w-5 text-brand-500" />
            )}
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;

