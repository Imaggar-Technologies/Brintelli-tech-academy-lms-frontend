import { CloudUpload, FileText, Link2 } from "lucide-react";
import PageHeader from "../../components/PageHeader";

const TutorUploadMaterials = () => {
  return (
    <>
      <PageHeader
        title="Upload Course Materials"
        description="Share decks, assignments, and reference documents. Students will get notified instantly."
        actions={
          <button className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-semibold text-brand-600 shadow-sm transition hover:bg-white/90">
            View Shared Library
          </button>
        }
      />
      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
          <h3 className="text-lg font-semibold text-slate-900">Upload Center</h3>
          <p className="mt-1 text-sm text-slate-500">Drag & drop files or paste external resource links.</p>
          <div className="mt-6 flex h-56 flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-brand-300 bg-brand-50 text-center text-slate-500">
            <CloudUpload className="h-10 w-10 text-brand-500" />
            <p className="text-sm font-semibold text-brand-600">Drop files here or browse</p>
            <p className="text-xs text-slate-500">PDF, PPT, ZIP up to 200 MB</p>
            <button className="rounded-xl bg-gradient-to-r from-brand-500 to-accent-500 px-4 py-2 text-sm font-semibold text-white shadow-soft transition hover:brightness-95">
              Select Files
            </button>
          </div>
          <div className="mt-6 space-y-4">
            <div>
              <label className="text-sm font-semibold text-slate-700">Attach link</label>
              <div className="mt-2 flex gap-2">
                <div className="relative flex-1">
                  <Link2 className="pointer-events-none absolute left-4 top-3 h-4 w-4 text-slate-400" />
                  <input
                    type="url"
                    placeholder="https://drive.google.com/..."
                    className="w-full rounded-xl border border-slate-200 bg-white px-11 py-2.5 text-sm text-slate-600 outline-none ring-brand-200 transition focus:border-brand-300 focus:ring-2"
                  />
                </div>
                <button className="rounded-xl bg-brand-700 px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-600">
                  Attach
                </button>
              </div>
            </div>
            <div>
              <label className="text-sm font-semibold text-slate-700">Add description</label>
              <textarea
                rows={3}
                placeholder="Context, instructions or preparation notes..."
                className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-2 text-sm text-slate-600 outline-none ring-brand-200 transition focus:border-brand-300 focus:ring-2"
              />
            </div>
          </div>
          <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3 text-sm text-slate-500">
              <input type="checkbox" id="notify" className="h-4 w-4 rounded border-slate-300 text-brand-500 focus:ring-brand-400" />
              <label htmlFor="notify">Notify students instantly</label>
            </div>
            <button className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-brand-500 to-accent-500 px-5 py-2 text-sm font-semibold text-white shadow-soft transition hover:brightness-95">
              Publish Materials
            </button>
          </div>
        </div>
        <div className="flex flex-col gap-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
            <h3 className="text-lg font-semibold text-slate-900">Recent Uploads</h3>
            <div className="mt-4 space-y-3 text-sm text-slate-600">
              {[
                { title: "Week 4 Deck.pdf", time: "Uploaded 2h ago", size: "12 MB" },
                { title: "Assignment Brief.docx", time: "Uploaded yesterday", size: "1.8 MB" },
                { title: "Case Study.zip", time: "Uploaded 3 days ago", size: "45 MB" },
              ].map((item) => (
                <div key={item.title} className="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3">
                  <div>
                    <p className="font-semibold text-slate-900">{item.title}</p>
                    <p className="text-xs text-slate-500">{item.time}</p>
                  </div>
                  <span className="text-xs font-semibold text-slate-500">{item.size}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
            <h3 className="text-lg font-semibold text-slate-900">Sharing Tips</h3>
            <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-slate-600">
              <li>Use descriptive names for quick discovery by students.</li>
              <li>Bundle code samples and documentation in structured folders.</li>
              <li>Tag materials in Discord post for cross-channel visibility.</li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export default TutorUploadMaterials;

