import { Timer, Filter, Tag, Target, CheckCircle2, XCircle } from "lucide-react";
import PageHeader from "../../components/PageHeader";

const certifications = ["AWS Cloud Practitioner", "AWS Solutions Architect", "Azure Fundamentals", "GCP Associate"];
const difficulties = ["Easy", "Medium", "Hard"];
const topics = ["Storage", "Networking", "Security", "Databases"];

const questions = [
  {
    id: 1,
    question: "Which AWS service should you use to create a decoupled architecture between microservices?",
    options: [
      { value: "a", label: "Amazon S3" },
      { value: "b", label: "Amazon SQS", correct: true },
      { value: "c", label: "Amazon DynamoDB" },
      { value: "d", label: "AWS Lambda" },
    ],
    tags: ["AWS – SQS", "Easy"],
    timer: "02:15",
    status: "correct",
  },
  {
    id: 2,
    question: "You need to design a highly available relational database on Azure. Which service fits best?",
    options: [
      { value: "a", label: "Azure Blob Storage" },
      { value: "b", label: "Azure Cosmos DB" },
      { value: "c", label: "Azure SQL Database", correct: true },
      { value: "d", label: "Azure Table Storage" },
    ],
    tags: ["Azure – SQL", "Medium"],
    timer: "01:32",
    status: "incorrect",
  },
];

const MCQPractice = () => {
  return (
    <>
      <PageHeader
        title="MCQ Practice Hub"
        description="Sharpen certification fundamentals across AWS, Azure, and GCP with timed MCQ drills."
      />
      <div className="grid gap-5 lg:grid-cols-[280px_1fr]">
        <aside className="flex flex-col gap-5 rounded-2xl border border-slate-200 bg-white p-5 shadow-soft">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900">Filters</h3>
            <Filter className="h-4 w-4 text-slate-400" />
          </div>
          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Certification</p>
            <select className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm text-slate-600 outline-none transition focus:border-brand-300 focus:ring-2 focus:ring-brand-200">
              {certifications.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Difficulty</p>
            <div className="flex flex-wrap gap-2">
              {difficulties.map((item) => (
                <button
                  key={item}
                  className="rounded-full border border-slate-200 px-3 py-1 text-xs font-semibold text-slate-500 transition hover:border-brand-300 hover:text-brand-600"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Topics</p>
            <div className="flex flex-wrap gap-2">
              {topics.map((item) => (
                <span key={item} className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-500">
                  <Tag className="h-3.5 w-3.5" />
                  {item}
                </span>
              ))}
            </div>
          </div>
          <button className="mt-auto rounded-xl bg-gradient-to-r from-brand-500 to-accent-500 px-4 py-2 text-sm font-semibold text-white shadow-soft transition hover:brightness-95">
            Start 30-question Set
          </button>
        </aside>

        <section className="flex flex-col gap-5">
          {questions.map((question) => (
            <article
              key={question.id}
              className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-5 shadow-soft transition hover:-translate-y-0.5 hover:border-brand-200"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                    Question {question.id}
                  </p>
                  <h3 className="mt-1 text-base font-semibold text-slate-900">{question.question}</h3>
                </div>
                <span className="inline-flex items-center gap-1 rounded-full border border-brand-200 bg-brand-50 px-3 py-1 text-xs font-semibold text-brand-600">
                  <Timer className="h-3.5 w-3.5" />
                  {question.timer}
                </span>
              </div>
              <div className="space-y-2">
                {question.options.map((option) => (
                  <label
                    key={option.value}
                    className={[
                      "flex cursor-pointer items-center gap-3 rounded-xl border px-3.5 py-2.5 text-sm",
                      option.correct
                        ? "border-brand-600/40 bg-brand-600/10 text-brand-600"
                        : "border-slate-200 bg-white text-slate-600 hover:border-brand-200",
                    ].join(" ")}
                  >
                    <input type="radio" name={`question-${question.id}`} className="h-4 w-4 rounded-full border border-slate-300 text-brand-500 focus:ring-brand-400" />
                    <span>{option.label}</span>
                  </label>
                ))}
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-semibold text-slate-500">
                <div className="flex flex-wrap items-center gap-2">
                  {question.tags.map((tag) => (
                    <span key={tag} className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-500">
                      <Tag className="h-3.5 w-3.5" />
                      {tag}
                    </span>
                  ))}
                </div>
                <span
                  className={[
                    "inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-semibold",
                    question.status === "correct"
                      ? "bg-brand-600/15 text-brand-600"
                      : "bg-brand-700/20 text-brand-700",
                  ].join(" ")}
                >
                  {question.status === "correct" ? (
                    <>
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      Correct
                    </>
                  ) : (
                    <>
                      <XCircle className="h-3.5 w-3.5" />
                      Incorrect
                    </>
                  )}
                </span>
              </div>
            </article>
          ))}

          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-soft">
            <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-400">Session Summary</h3>
            <div className="mt-3 grid gap-3 md:grid-cols-3">
              <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Score</p>
                <p className="mt-1 text-lg font-semibold text-slate-900">18 / 25</p>
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Accuracy</p>
                <p className="mt-1 text-lg font-semibold text-slate-900">72%</p>
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Time Taken</p>
                <p className="mt-1 text-lg font-semibold text-slate-900">32 mins</p>
              </div>
            </div>
            <button className="mt-4 inline-flex items-center gap-2 rounded-xl bg-brand-700 px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-600">
              <Target className="h-4 w-4" />
              Start Adaptive Set
            </button>
          </div>
        </section>
      </div>
    </>
  );
};

export default MCQPractice;


