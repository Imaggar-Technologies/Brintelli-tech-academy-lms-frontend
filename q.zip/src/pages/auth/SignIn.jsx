import { useNavigate } from "react-router-dom";

const SignIn = () => {
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();
    navigate("/auth/choose-role");
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-100 px-4 py-10">
      <div className="w-full max-w-md overflow-hidden rounded-2xl bg-white shadow-soft">
        <div className="bg-gradient-to-br from-brand-500 via-brand-500/90 to-accent-500 px-6 py-5 text-white">
          <p className="text-xs font-semibold uppercase tracking-wide text-white/80">
            Brintelli Tech Academy
          </p>
          <h1 className="text-2xl font-semibold">Sign in to your portal</h1>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4 px-6 py-6">
          <div className="space-y-2">
            <label htmlFor="email" className="text-sm font-medium text-slate-700">
              Email address
            </label>
            <input
              id="email"
              type="email"
              required
              placeholder="you@brintelli.com"
              className="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm text-slate-600 outline-none transition focus:border-brand-300 focus:ring-2 focus:ring-brand-200"
            />
          </div>
          <div className="space-y-2">
            <label htmlFor="password" className="text-sm font-medium text-slate-700">
              Password
            </label>
            <input
              id="password"
              type="password"
              required
              placeholder="••••••••"
              className="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm text-slate-600 outline-none transition focus:border-brand-300 focus:ring-2 focus:ring-brand-200"
            />
          </div>
          <button
            type="submit"
            className="w-full rounded-xl bg-gradient-to-r from-brand-500 to-accent-500 px-4 py-2.5 text-sm font-semibold text-white shadow-soft transition hover:brightness-95"
          >
            Sign In
          </button>
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>© {new Date().getFullYear()} Brintelli Academy</span>
            <span className="font-semibold text-brand-600">Forgot password?</span>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SignIn;


