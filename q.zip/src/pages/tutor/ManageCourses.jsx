import { Pencil, Plus } from "lucide-react";
import PageHeader from "../../components/PageHeader";
import Table from "../../components/Table";

const columns = [
  { key: "title", title: "Course" },
  { key: "cohort", title: "Cohort" },
  { key: "students", title: "Students" },
  { key: "status", title: "Status" },
  {
    key: "actions",
    title: "Actions",
    render: () => (
      <button className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-brand-500 to-accent-500 px-3 py-2 text-xs font-semibold text-white shadow-soft transition hover:brightness-95">
        <Pencil className="h-3.5 w-3.5" />
        Edit
      </button>
    ),
  },
];

const data = [
  { id: 1, title: "Backend Engineering Mastery", cohort: "BE-2025A", students: 118, status: "Active" },
  { id: 2, title: "Advanced DSA Sprint", cohort: "DSA-2025A", students: 96, status: "Active" },
  { id: 3, title: "System Design: Scaling Products", cohort: "SD-2025A", students: 84, status: "Active" },
  { id: 4, title: "Career Accelerator Bootcamp", cohort: "CA-2025A", students: 60, status: "Upcoming" },
];

const TutorManageCourses = () => {
  return (
    <>
      <PageHeader
        title="Manage Courses"
        description="Update curriculum, monitor cohort rosters, and keep course delivery aligned with outcomes."
        actions={
          <button className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-semibold text-brand-600 shadow-sm transition hover:bg-white/90">
            <Plus className="h-4 w-4" />
            Create New Course
          </button>
        }
      />
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-slate-900">Course Inventory</h3>
          <button className="rounded-xl bg-brand-700 px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-600">
            Export Roster
          </button>
        </div>
        <div className="mt-4">
          <Table columns={columns} data={data} />
        </div>
      </div>
    </>
  );
};

export default TutorManageCourses;

