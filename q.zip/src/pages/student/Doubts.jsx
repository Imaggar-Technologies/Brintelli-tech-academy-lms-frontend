import { MessageCircleQuestion, Tag } from "lucide-react";
import PageHeader from "../../components/PageHeader";

const doubts = [
  {
    id: 1,
    title: "When to choose write-through cache over write-back?",
    category: "System Design",
    status: "Mentor replying",
    timestamp: "12 mins ago",
  },
  {
    id: 2,
    title: "Optimizing DP solution for partition problem",
    category: "DSA",
    status: "Peer discussion",
    timestamp: "25 mins ago",
  },
  {
    id: 3,
    title: "Handling auth in microservices without tight coupling",
    category: "Architecture",
    status: "Escalated to mentor",
    timestamp: "1 hour ago",
  },
];

const StudentDoubts = () => {
  return (
    <>
      <PageHeader
        title="Doubt Resolution Queue"
        description="Drop technical questions, track mentor responses, and leverage peer community support."
        actions={
          <button className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-semibold text-brand-600 shadow-sm transition hover:bg-white/90">
            Ask a Doubt
          </button>
        }
      />
      <div className="flex flex-col gap-4">
        {doubts.map((doubt) => (
          <div
            key={doubt.id}
            className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-6 shadow-soft transition hover:-translate-y-1 hover:border-brand-200 hover:shadow-soft"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 className="text-lg font-semibold text-slate-900">{doubt.title}</h3>
                <div className="mt-2 inline-flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-500">
                  <Tag className="h-3.5 w-3.5" />
                  {doubt.category}
                </div>
              </div>
              <span className="inline-flex items-center gap-2 rounded-full bg-brand-600/15 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-brand-600">
                <MessageCircleQuestion className="h-3.5 w-3.5" />
                {doubt.status}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Submitted by you</span>
              <span>{doubt.timestamp}</span>
            </div>
            <div className="flex flex-wrap gap-3">
              <button className="rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:border-brand-300 hover:text-brand-600">
                Add Clarification
              </button>
              <button className="rounded-xl bg-brand-700 px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-600">
                View Thread
              </button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default StudentDoubts;

