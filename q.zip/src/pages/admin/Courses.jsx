import { BookOpen } from "lucide-react";
import PageHeader from "../../components/PageHeader";
import Table from "../../components/Table";

const columns = [
  { key: "title", title: "Course" },
  { key: "category", title: "Category" },
  { key: "batches", title: "Batches" },
  { key: "students", title: "Learners" },
  { key: "status", title: "Status" },
];

const data = [
  {
    id: 1,
    title: "Backend Engineering Mastery",
    category: "Backend",
    batches: 3,
    students: 340,
    status: "Active",
  },
  {
    id: 2,
    title: "Advanced Data Structures & Algorithms",
    category: "DSA",
    batches: 4,
    students: 480,
    status: "Active",
  },
  {
    id: 3,
    title: "System Design for Scale",
    category: "Architecture",
    batches: 2,
    students: 210,
    status: "Active",
  },
];

const AdminCourses = () => {
  return (
    <>
      <PageHeader
        title="Course Catalog"
        description="Keep the curriculum fresh, align mentors, and track learner adoption per course."
        actions={
          <button className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-semibold text-brand-600 shadow-sm transition hover:bg-white/90">
            <BookOpen className="h-4 w-4" />
            Add Course
          </button>
        }
      />
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-slate-900">Active Programs</h3>
          <button className="rounded-xl bg-brand-700 px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-600">
            Export Catalog
          </button>
        </div>
        <div className="mt-4">
          <Table columns={columns} data={data} />
        </div>
      </div>
    </>
  );
};

export default AdminCourses;

