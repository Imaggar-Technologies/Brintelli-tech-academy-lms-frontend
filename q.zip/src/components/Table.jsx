const Table = ({ columns = [], data = [], emptyLabel = "No data available" }) => {
  return (
    <div className="overflow-hidden rounded-2xl border border-brintelli-border bg-white shadow-soft">
      <div className="max-h-[460px] overflow-auto">
        <table className="min-w-full divide-y divide-brintelli-border/80">
          <thead className="bg-brintelli-base">
            <tr>
              {columns.map((column) => (
                <th
                  key={column.key}
                  className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-text-muted"
                >
                  {column.title}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-brintelli-border/70 bg-white">
            {data.length === 0 && (
              <tr>
                <td
                  colSpan={columns.length}
                  className="px-6 py-12 text-center text-sm text-text-muted"
                >
                  {emptyLabel}
                </td>
              </tr>
            )}
            {data.map((row, rowIndex) => (
              <tr key={row.id ?? rowIndex} className="hover:bg-brintelli-baseAlt/70">
                {columns.map((column) => (
                  <td key={column.key} className="whitespace-nowrap px-6 py-4 text-sm text-text-soft">
                    {column.render ? column.render(row) : row[column.key]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Table;

