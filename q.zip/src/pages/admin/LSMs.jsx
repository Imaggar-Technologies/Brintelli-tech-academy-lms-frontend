import { HeartHandshake } from "lucide-react";
import PageHeader from "../../components/PageHeader";
import Table from "../../components/Table";

const columns = [
  { key: "name", title: "LSM" },
  { key: "mentees", title: "Mentees" },
  { key: "satisfaction", title: "CSAT" },
  { key: "risk", title: "Risk Cases" },
  { key: "status", title: "Status" },
];

const data = [
  {
    id: 1,
    name: "Priya Sharma",
    mentees: 48,
    satisfaction: "4.9",
    risk: 3,
    status: "Active",
  },
  {
    id: 2,
    name: "Harish Kumar",
    mentees: 40,
    satisfaction: "4.7",
    risk: 5,
    status: "Active",
  },
  {
    id: 3,
    name: "Shalini Menon",
    mentees: 35,
    satisfaction: "4.6",
    risk: 2,
    status: "Onboarding",
  },
];

const AdminLsMs = () => {
  return (
    <>
      <PageHeader
        title="Learning Success Managers"
        description="Track LSM capacity, mentee satisfaction, and wellbeing escalations."
        actions={
          <button className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-semibold text-brand-600 shadow-sm transition hover:bg-white/90">
            <HeartHandshake className="h-4 w-4" />
            Add LSM
          </button>
        }
      />
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-slate-900">LSM Network Overview</h3>
          <button className="rounded-xl bg-brand-700 px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-600">
            Export Metrics
          </button>
        </div>
        <div className="mt-4">
          <Table columns={columns} data={data} />
        </div>
      </div>
    </>
  );
};

export default AdminLsMs;

