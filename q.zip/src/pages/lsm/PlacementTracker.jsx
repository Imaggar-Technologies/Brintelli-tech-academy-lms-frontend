import { Briefcase, CircleDollarSign, Rocket } from "lucide-react";
import PageHeader from "../../components/PageHeader";
import StatsCard from "../../components/StatsCard";

const LsmPlacementTracker = () => {
  return (
    <>
      <PageHeader
        title="Placement Tracker"
        description="Monitor offers, interview pipelines, and mentee readiness milestones."
        actions={
          <button className="rounded-xl bg-white px-4 py-2 text-sm font-semibold text-brand-600 shadow-sm transition hover:bg-white/90">
            Share With Placement Team
          </button>
        }
      />
      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
        <StatsCard icon={Briefcase} value="14" label="Active Interviews" trend="+5 this week" />
        <StatsCard icon={Rocket} value="6" label="Offers Secured" trend="Congrats 🎉" />
        <StatsCard icon={CircleDollarSign} value="24 LPA" label="Avg Offer CTC" trend="+12% YoY" />
        <StatsCard icon={Briefcase} value="9" label="Company Connects" trend="Follow ups pending" trendType="negative" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
          <h3 className="text-lg font-semibold text-slate-900">Offer Pipeline</h3>
          <div className="mt-4 space-y-3 text-sm text-slate-600">
            {[
              { mentee: "Aishwarya K", status: "Offer from Razorpay · Pending acceptance" },
              { mentee: "Shraddha P", status: "Round 3 at Atlassian next Monday" },
              { mentee: "Rohit S", status: "Hiring challenge at Meesho this weekend" },
            ].map((item) => (
              <div key={item.mentee} className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
                <p className="font-semibold text-slate-900">{item.mentee}</p>
                <p className="text-xs text-slate-500">{item.status}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft">
          <h3 className="text-lg font-semibold text-slate-900">Action Items</h3>
          <ul className="mt-4 list-disc space-y-2 pl-5 text-sm text-slate-600">
            <li>Coordinate mock HR interview for Karan Gupta.</li>
            <li>Follow up with placement partner on Atlassian referrals.</li>
            <li>Share portfolio review checklist with mentees this week.</li>
          </ul>
          <button className="mt-5 rounded-xl bg-brand-700 px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-600">
            Update Tracker
          </button>
        </div>
      </div>
    </>
  );
};

export default LsmPlacementTracker;

