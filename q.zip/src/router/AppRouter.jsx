import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import AppLayout from "../components/AppLayout";

// Auth pages
import SignIn from "../pages/auth/SignIn";
import ChooseRole from "../pages/auth/ChooseRole";

// Student pages
import StudentDashboard from "../pages/student/Dashboard";
import StudentMyCourses from "../pages/student/MyCourses";
import StudentCourseDetail from "../pages/student/CourseDetail";
import StudentLiveClasses from "../pages/student/LiveClasses";
import StudentRecordings from "../pages/student/Recordings";
import StudentAssignments from "../pages/student/Assignments";
import StudentTests from "../pages/student/Tests";
import StudentMockInterviews from "../pages/student/MockInterviews";
import StudentDoubts from "../pages/student/Doubts";
import StudentProfile from "../pages/student/Profile";
import StudentMCQPractice from "../pages/student/MCQPractice";
import StudentCertifications from "../pages/student/CertificationsMock";
import StudentCodePlayground from "../pages/student/CodePlayground";
import StudentPlacementAssistance from "../pages/student/PlacementAssistance";

// Tutor pages
import TutorDashboard from "../pages/tutor/Dashboard";
import TutorManageCourses from "../pages/tutor/ManageCourses";
import TutorLessons from "../pages/tutor/Lessons";
import TutorUploadMaterials from "../pages/tutor/UploadMaterials";
import TutorLiveClassController from "../pages/tutor/LiveClassController";
import TutorStudentsList from "../pages/tutor/StudentsList";
import TutorStudentPerformance from "../pages/tutor/StudentPerformance";

// LSM pages
import LsmDashboard from "../pages/lsm/Dashboard";
import LsmMenteesList from "../pages/lsm/MenteesList";
import LsmMenteeProfile from "../pages/lsm/MenteeProfile";
import LsmSessionSchedule from "../pages/lsm/SessionSchedule";
import LsmProgressReports from "../pages/lsm/ProgressReports";
import LsmPlacementTracker from "../pages/lsm/PlacementTracker";

// Admin pages
import AdminDashboard from "../pages/admin/Dashboard";
import AdminBatches from "../pages/admin/Batches";
import AdminStudents from "../pages/admin/Students";
import AdminTutors from "../pages/admin/Tutors";
import AdminLsMs from "../pages/admin/LSMs";
import AdminCourses from "../pages/admin/Courses";
import AdminPlacement from "../pages/admin/Placement";
import AdminSettings from "../pages/admin/Settings";

// Placement role pages
import PlacementDashboard from "../pages/placement/PlacementDashboard";

const NotFound = () => (
  <div className="flex flex-1 items-center justify-center rounded-2xl border border-dashed border-slate-200 bg-white p-10 text-center">
    <div className="space-y-3">
      <h2 className="text-2xl font-semibold text-slate-900">Page not found</h2>
      <p className="text-sm text-slate-500">Please select a module using the sidebar navigation.</p>
    </div>
  </div>
);

const AppRouter = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/auth">
          <Route path="signin" element={<SignIn />} />
          <Route path="choose-role" element={<ChooseRole />} />
        </Route>
        <Route path="/" element={<AppLayout />}>
          <Route index element={<Navigate to="/student/dashboard" replace />} />

          <Route path="student">
            <Route path="dashboard" element={<StudentDashboard />} />
            <Route path="my-courses" element={<StudentMyCourses />} />
            <Route path="course/:id" element={<StudentCourseDetail />} />
            <Route path="live-classes" element={<StudentLiveClasses />} />
            <Route path="recordings" element={<StudentRecordings />} />
            <Route path="assignments" element={<StudentAssignments />} />
            <Route path="tests" element={<StudentTests />} />
            <Route path="mock-interviews" element={<StudentMockInterviews />} />
            <Route path="doubts" element={<StudentDoubts />} />
            <Route path="mcq-practice" element={<StudentMCQPractice />} />
            <Route path="certifications" element={<StudentCertifications />} />
            <Route path="code-playground" element={<StudentCodePlayground />} />
            <Route path="placement-assistance" element={<StudentPlacementAssistance />} />
            <Route path="profile" element={<StudentProfile />} />
          </Route>

          <Route path="tutor">
            <Route path="dashboard" element={<TutorDashboard />} />
            <Route path="manage-courses" element={<TutorManageCourses />} />
            <Route path="lessons" element={<TutorLessons />} />
            <Route path="upload-materials" element={<TutorUploadMaterials />} />
            <Route path="live-class-controller" element={<TutorLiveClassController />} />
            <Route path="students" element={<TutorStudentsList />} />
            <Route path="student-performance" element={<TutorStudentPerformance />} />
          </Route>

          <Route path="lsm">
            <Route path="dashboard" element={<LsmDashboard />} />
            <Route path="mentees" element={<LsmMenteesList />} />
            <Route path="mentee/:id" element={<LsmMenteeProfile />} />
            <Route path="session-schedule" element={<LsmSessionSchedule />} />
            <Route path="progress-reports" element={<LsmProgressReports />} />
            <Route path="placement-tracker" element={<LsmPlacementTracker />} />
          </Route>

          <Route path="admin">
            <Route path="dashboard" element={<AdminDashboard />} />
            <Route path="batches" element={<AdminBatches />} />
            <Route path="students" element={<AdminStudents />} />
            <Route path="tutors" element={<AdminTutors />} />
            <Route path="lsms" element={<AdminLsMs />} />
            <Route path="courses" element={<AdminCourses />} />
            <Route path="placement" element={<AdminPlacement />} />
            <Route path="settings" element={<AdminSettings />} />
          </Route>

          <Route path="placement">
            <Route path="dashboard" element={<PlacementDashboard />} />
          </Route>

          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
};

export default AppRouter;

