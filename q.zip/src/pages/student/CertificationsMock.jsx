import { Award, ArrowRight } from "lucide-react";
import PageHeader from "../../components/PageHeader";
import ProgressBar from "../../components/ProgressBar";

const tracks = [
  {
    id: 1,
    title: "AWS Cloud Practitioner",
    description: "Core cloud concepts, pricing models, shared responsibility.",
    progress: 68,
  },
  {
    id: 2,
    title: "AWS Solutions Architect",
    description: "Design scalable architectures across networking and storage.",
    progress: 42,
  },
  {
    id: 3,
    title: "Azure Fundamentals",
    description: "Azure services overview, management tools, and governance.",
    progress: 54,
  },
  {
    id: 4,
    title: "GCP Associate",
    description: "GCP compute, storage, and networking primitives with case studies.",
    progress: 26,
  },
];

const CertificationsMock = () => {
  return (
    <>
      <PageHeader
        title="Certification Mock Center"
        description="Pick a certification track, monitor progress, and launch full-length timed mock tests."
      />
      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {tracks.map((track) => (
          <div
            key={track.id}
            className="flex flex-col gap-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-soft transition hover:-translate-y-1 hover:border-brand-200"
          >
            <div className="flex items-start gap-3">
              <div className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-brand-500/10 to-accent-500/10 text-brand-600">
                <Award className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-slate-900">{track.title}</h3>
                <p className="text-sm text-slate-500">{track.description}</p>
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wide text-slate-400">
                <span>Progress</span>
                <span className="text-slate-600">{track.progress}%</span>
              </div>
              <div className="mt-2">
                <ProgressBar value={track.progress} />
              </div>
            </div>
            <div className="mt-auto flex items-center justify-between text-xs text-slate-500">
              <span>Mock tests attempted: 3</span>
              <span>Average score: 72%</span>
            </div>
            <button className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-brand-500 to-accent-500 px-4 py-2 text-sm font-semibold text-white shadow-soft transition hover:brightness-95">
              Start Full Mock Test
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </>
  );
};

export default CertificationsMock;


